import 'package:flutter/material.dart';

class DetailAudioPage extends StatefulWidget {
  const DetailAudioPage({Key? key}) : super(key: key);

  @override
  State<DetailAudioPage> createState() => _DetailAudioPageState();
}

class _DetailAudioPageState extends State<DetailAudioPage> {
  @override
  Widget build(BuildContext context) {
    final double screenHeight  = MediaQuery.of(context).size.height;
    final double screenWidth  = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.lightBlueAccent,
      body: Stack(
        children: [
            Positioned(
              top:0,
                left:0,
                right:0,
                height: screenHeight/3,
                child: Container(
                color:Colors.blue,
                )),
            Positioned(
              top:0,left:0,right:0,
              child: AppBar(
                leading: IconButton(
                icon:Icon(Icons.arrow_back_ios,),
                onPressed: (){},
            ),
                // actions:[
                //   IconButton(
                //     icon:Icon(Icons.search,),
                //     onPressed: (){},
                //   ),
                // ],
                backgroundColor: Colors.transparent,
                elevation:0.0,
            ),
            ),
            Positioned(
              top: screenHeight * 0.2,left:0,right:0,
              height:screenHeight * 0.36,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(40),
                  color:Colors.white,
                ),
                child: Column(
                  children: [
                    SizedBox(height:screenHeight*0.1,),
                    Text("Statue Of Liberty",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        fontFamily: "Avenir",
                      ),
                    ),
                    Text("United States Of America",
                    style: TextStyle(
                      fontSize: 14,
                    ),)
                  ],
                )
              )
            )

        ],
      )
    );
  }
}
